import type { InjectionKey } from 'vue';
import type { BreadcrumbProps } from 'element-plus/es/components/breadcrumb';
export declare const breadcrumbKey: InjectionKey<BreadcrumbProps>;
