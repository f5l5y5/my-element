import type { Ref } from 'vue';
export declare const useThrottleRender: (loading: Ref<boolean>, throttle?: number) => Ref<boolean>;
