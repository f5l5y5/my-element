export declare const POPPER_CONTAINER_ID: string;
export declare const POPPER_CONTAINER_SELECTOR: string;
export declare const usePopperContainer: () => void;
