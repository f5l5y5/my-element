export declare const useZIndex: () => {
    initialZIndex: import("vue").Ref<number>;
    currentZIndex: import("vue").ComputedRef<number>;
    nextZIndex: () => number;
};
