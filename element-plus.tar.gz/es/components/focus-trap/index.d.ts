import ElFocusTrap from './src/focus-trap.vue';
export { ElFocusTrap };
export default ElFocusTrap;
export * from './src/tokens';
export * from './src/utils';
