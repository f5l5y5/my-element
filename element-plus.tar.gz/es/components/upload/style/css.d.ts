import 'element-plus/es/components/base/style/css';
import 'element-plus/theme-chalk/el-upload.css';
import 'element-plus/es/components/progress/style/css';
