import 'element-plus/es/components/base/style';
import 'element-plus/theme-chalk/src/upload.scss';
import 'element-plus/es/components/progress/style';
