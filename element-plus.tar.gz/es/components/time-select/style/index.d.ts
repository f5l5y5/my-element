import 'element-plus/es/components/base/style';
import 'element-plus/theme-chalk/src/time-select.scss';
import 'element-plus/es/components/scrollbar/style';
import 'element-plus/es/components/popper/style';
import 'element-plus/es/components/input/style';
import 'element-plus/es/components/select/style';
import 'element-plus/es/components/option/style';
