export { OnlyChild as ElOnlyChild } from './src/only-child';
export * from './src/only-child';
