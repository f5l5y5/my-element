import 'element-plus/es/components/base/style';
import 'element-plus/es/components/input/style';
import 'element-plus/es/components/tag/style';
import 'element-plus/es/components/option/style';
import 'element-plus/es/components/option-group/style';
import 'element-plus/es/components/scrollbar/style';
import 'element-plus/es/components/popper/style';
import 'element-plus/theme-chalk/src/select.scss';
