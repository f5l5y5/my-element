import type { MenuProps } from './menu';
export default function useMenuColor(props: MenuProps): import("vue").ComputedRef<string>;
