import type { MenuProps } from './menu';
export declare const useMenuCssVar: (props: MenuProps, level: number) => import("vue").ComputedRef<Record<string, string>>;
