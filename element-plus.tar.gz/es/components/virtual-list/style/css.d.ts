import 'element-plus/es/components/base/style/css';
import 'element-plus/theme-chalk/el-virtual-list.css';
import 'element-plus/es/components/scrollbar/style/css';
